# Sorting Visualizer

https://user-images.githubusercontent.com/89158929/130247537-80d89244-f226-48ad-ac6c-1ba3d64826f2.mp4

### Algorithms Implemented 

  - Quick Sort 
  - Merge Sort
  - Selection Sort
  - Bubble Sort
### Technologies Used 
  - HTML
  - CSS
  - BootStrap
  - JS
